
function nombresPremiers() {
  let texte = "Nombres premiers entre 1 et 100 :\n";
  for (let nombre = 2; nombre <= 100; nombre++) {
    let estPremier = true;
    for (let i = 2; i < nombre; i++) {
      if (nombre % i === 0) {
        estPremier = false;
        break;
      }
    }
    if (estPremier) texte += nombre + " ";
  }
  document.getElementById("resultat").textContent = texte;
}
function facteurs() {
  let nombre = parseInt(prompt("Entrez un nombre :"));
  let texte = "Facteurs de " + nombre + " : ";
  for (let i = 1; i <= nombre; i++) {
    if (nombre % i === 0) {
      texte += i + " ";
    }
  }
  document.getElementById("resultat").textContent = texte;
}
function moyennePositifs() {
  let somme = 0;
  let compteur = 0;
  let nombre;

  do {
    nombre = parseFloat(prompt("Entrez un nombre positif (ou un nombre négatif pour arrêter) :"));
    if (nombre >= 0) {
      somme += nombre;
      compteur++;
    }
  } while (nombre >= 0);

  let texte = "";
  if (compteur > 0) {
    let moyenne = somme / compteur;
    texte = "La moyenne des " + compteur + " nombres positifs est : " + moyenne;
  } else {
    texte = "Aucun nombre positif saisi.";
  }

  document.getElementById("resultat").textContent = texte;
}
function triangleEtoiles() {
  let hauteur = parseInt(prompt("Entrez la hauteur du triangle :"));
  let motif = "";
  for (let i = 1; i <= hauteur; i++) {
    motif += "*".repeat(i) + "\n";
  }
  document.getElementById("resultat").textContent = motif;
}

